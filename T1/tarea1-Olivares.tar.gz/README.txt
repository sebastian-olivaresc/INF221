Para ejecutar los programas hay que entrar a la carpeta respectiva
ejecutar ./make
luego para pasar el input ./problema < $path al input$/input.dat
