Para ejecutar el programa se extraen los archivos, se entra a la carpeta
respectiva.
Ejecutar ./make
Luego para pasar el input ./problema1 < $path al input$/input.dat

Testeado en:
gcc (GCC) 12.2.0
Linux 6.0.10-arch2-1 x86_64
